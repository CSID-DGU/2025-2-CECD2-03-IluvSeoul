from core.action.decorators.action import action
from core.action.decorators.action_method import action_method

__all__ = ['action', 'action_method']
