class TestLogic:
    @staticmethod
    def proc():
        return 'test'