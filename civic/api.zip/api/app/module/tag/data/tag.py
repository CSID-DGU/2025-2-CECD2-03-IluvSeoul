class Tag:
    def __init__(self, id: int, type: str, key: str, name: str):
        self.id = id
        self.type = type
        self.key = key
        self.name = name